document.getElementById('login__form').addEventListener('susbmit', async(e) => {
    e.preventDefault();

    const username = document.getElementById('username');
    const password = document.getElementById('password');

    
})